package com.example.studentskasluzba;

public class ParentTableStudenti {
    public static final String TABLE_NAME = "studenti";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_USER = "username";
    public static final String COLUMN_IME = "ime";
    public static final String COLUMN_PREZIME = "prezime";
    public static final String COLUMN_JMBG = "jmbg";
    public static final String COLUMN_INDEKS = "indeks";
}
