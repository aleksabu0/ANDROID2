package com.example.studentskasluzba;

public class ParentTablePredmeti {
    public static final String TABLE_NAME = "predmeti";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_IMEPREDMETA = "ime";
    //public static final String COLUMN_P = "name";
}
