package com.example.studentskasluzba;

public class ChildTableStudenti {
    public static final String TABLE_NAME = "student_predmeti";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_PARENT_ID = "parent_id";
    public static final String COLUMN_IMEPREDMETA = "ime_predmeta";
    public static final String COLUMN_GODINA = "godina";
    public static final String COLUMN_OSV1 = "osv1";
    public static final String COLUMN_OSV2 = "osv2";
    public static final String COLUMN_OSV3 = "osv3";
    public static final String COLUMN_OSV4 = "osv4";
    public static final String COLUMN_OSV5 = "osv5";
}
