package com.example.studentskasluzba;

public class ChildTablePredmeti {
    public static final String TABLE_NAME = "kategorije";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_PARENT_ID = "parent_id";
    public static final String COLUMN_GODINA = "godina";
    public static final String COLUMN_K1 = "k1";
    public static final String COLUMN_MIN1 = "min1";
    public static final String COLUMN_MAX1 = "max1";
    public static final String COLUMN_K2 = "k2";
    public static final String COLUMN_MIN2 = "min2";
    public static final String COLUMN_MAX2 = "max2";
    public static final String COLUMN_K3 = "k3";
    public static final String COLUMN_MIN3 = "min3";
    public static final String COLUMN_MAX3 = "max3";
    public static final String COLUMN_K4 = "k4";
    public static final String COLUMN_MIN4 = "min4";
    public static final String COLUMN_MAX4 = "max4";
    public static final String COLUMN_K5 = "k5";
    public static final String COLUMN_MIN5 = "min5";
    public static final String COLUMN_MAX5 = "max5";
}
